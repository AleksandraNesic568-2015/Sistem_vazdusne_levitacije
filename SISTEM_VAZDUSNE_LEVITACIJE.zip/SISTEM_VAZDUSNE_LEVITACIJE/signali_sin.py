import math
class Lift:
    def h(self,x):
        if (x < 0):
            return 0.0
        elif (x > 0):
            return 1.0
        else:
            return 0.5
    def __init__(self):  
	self.period = 0.2  
        self.duration = 25  
        self.n = 0
        self.d = 0
    def loop(self,t,y):  
        r = 10 * math.sin(2*t)
        return r  
